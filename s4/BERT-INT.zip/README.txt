Please download https://github.com/kosugi11037/bert-int/, put it in that folder and replace the path.
