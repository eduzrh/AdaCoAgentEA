Please download https://github.com/DexterZeng/BETA, put it in that folder and replace the path.
